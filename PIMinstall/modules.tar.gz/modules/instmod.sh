#!/bin/sh

MODULE=$1

gzip -dc $MODULE.tar.gz | tar xf -
cd $MODULE
perl Makefile.PL INST_LIB=$2 INST_ARCHLIB=$3 
#> /dev/null
echo "\n"
echo "\n"
echo "\n"
echo "\n"
echo ""
make > /dev/null
